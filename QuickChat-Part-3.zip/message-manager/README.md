# PROG5121POE — QuickChat

This continues the supplied Part 2 QuickChat project. It keeps the registration/login flow and message-sending choices, adds the Part 3 stored-message menu, and reads the Part 2 `messages.json` format.

## Run

From this directory:

```sh
mvn test
mvn exec:java
```

Register and log in, then choose **4) Stored Messages** for sender/recipient listing, longest-message lookup, message-ID search, recipient search, hash deletion, or the full report. The existing Part 2 options remain in place.

## Data

Stored messages continue to use `messages.json` in the working directory. Older Part 2 files with `messageID`, `messageHash`, `recipient`, and `message` fields remain readable; the updated file also records the sender. The sample assignment messages are used by the automated tests and are not preloaded into a user's arrays.

Message IDs, hashes, sent messages, disregarded messages, and stored messages are populated from the user's actions and the stored JSON file. The Part 3 unit tests cover array population, longest stored message, ID and recipient searches, hash deletion, JSON loading/saving, and report details.
