package quickchatapp;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class MessageTest {
    @TempDir
    Path temporaryDirectory;

    private Message messageOne;
    private Message messageFour;

    @BeforeEach
    void setUp() throws IOException {
        Message.resetAll();
        Message.loadStoredMessages(
                Path.of("src", "test", "resources", "messages.json"));

        messageOne = new Message(
                "0100000001", 1, "+27834557896",
                "Did you get the cake?", "Developer");
        Message.addMessageToArray(messageOne, MessageStatus.SENT);

        Message messageThree = new Message(
                "0300000003", 3, "+27834484567",
                "Yohoooo, I am at your gate.", "Developer");
        Message.addMessageToArray(messageThree, MessageStatus.DISREGARDED);

        messageFour = new Message(
                "0838884567", 4, "",
                "It is dinner time !", "0838884567");
        Message.addMessageToArray(messageFour, MessageStatus.SENT);
    }

    @Test
    void arraysContainTheExpectedMessagesAndParallelIDsAndHashes() {
        assertArrayEquals(
                new String[]{"Did you get the cake?", "It is dinner time !"},
                Arrays.stream(Message.getSentMessagesArray())
                        .map(Message::getMessageText)
                        .toArray(String[]::new)
        );
        assertEquals(2, Message.getStoredMessagesArray().length);
        assertEquals(1, Message.getDisregardedMessagesArray().length);
        assertEquals(5, Message.getMessageHashes().length);
        assertEquals(5, Message.getMessageIDs().length);
        assertTrue(Arrays.asList(Message.getMessageIDs())
                .contains("0838884567"));
        assertTrue(Arrays.asList(Message.getMessageHashes())
                .contains(messageFour.getMessageHash()));
    }

    @Test
    void longestStoredMessageReturnsTheExpectedMessage() {
        assertEquals(
                "Where are you? You are late! I have asked you to be on time.",
                Message.getLongestStoredMessage().orElseThrow().getMessageText()
        );
    }

    @Test
    void messageIDSearchFindsMessageFourAndReturnsItsText() {
        Message found = Message.findByMessageID("0838884567").orElseThrow();

        assertEquals("It is dinner time !", found.getMessageText());
        assertEquals("", found.getRecipient());
    }

    @Test
    void recipientSearchReturnsSentAndStoredMessagesButNotDisregardedOnes() {
        List<String> found = Message.findMessagesForRecipient("+27838884567")
                .stream()
                .map(Message::getMessageText)
                .toList();

        assertEquals(
                List.of(
                        "Where are you? You are late! I have asked you to be on time.",
                        "Ok, I am leaving without you."
                ),
                found
        );
    }

    @Test
    void deleteByHashRemovesStoredMessageAndUpdatesItsJSONFile()
            throws IOException {
        Message target = Message.getStoredMessagesArray()[0];
        Path file = temporaryDirectory.resolve("messages.json");

        Message deleted = Message.deleteByHash(
                target.getMessageHash(), file).orElseThrow();
        Message.saveStoredMessages(file);
        Message.loadStoredMessages(file);

        assertEquals(target.getMessageText(), deleted.getMessageText());
        assertEquals(1, Message.getStoredMessagesArray().length);
        assertFalse(Message.findByMessageID(target.getMessageID()).isPresent());
    }

    @Test
    void reportIncludesMessageHashRecipientMessageAndStatus() {
        String report = Message.createFullReport();

        assertTrue(report.contains("Message Hash: " + messageOne.getMessageHash()));
        assertTrue(report.contains("Recipient: +27834557896"));
        assertTrue(report.contains("Message: Did you get the cake?"));
        assertTrue(report.contains("Status: STORED"));
        assertTrue(report.contains("Status: SENT"));
    }

    @Test
    void storedMessagesLoadFromAndSaveToPartTwoJSONFormat() throws IOException {
        Path file = temporaryDirectory.resolve("messages.json");
        Message.saveStoredMessages(file);
        Message.resetAll();
        Message.loadStoredMessages(file);

        assertEquals(2, Message.getStoredMessagesArray().length);
        assertEquals(
                "Where are you? You are late! I have asked you to be on time.",
                Message.getStoredMessagesArray()[0].getMessageText()
        );
        assertEquals(
                Message.getStoredMessagesArray()[0].getMessageHash(),
                "02:2:WHERETIME"
        );
    }
}
